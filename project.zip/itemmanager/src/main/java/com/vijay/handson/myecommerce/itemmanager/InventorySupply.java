package com.vijay.handson.myecommerce.itemmanager;

public class InventorySupply {
private int itemId;
private int qty;
private int storeId;
public int getItemId() {
	return itemId;
}
public void setItemId(int itemId) {
	this.itemId = itemId;
}
public int getQty() {
	return qty;
}
public void setQty(int qty) {
	this.qty = qty;
}
public int getStoreId() {
	return storeId;
}
public void setStoreId(int storeId) {
	this.storeId = storeId;
}
public InventorySupply(int itemId, int qty, int storeId) {
	super();
	this.itemId = itemId;
	this.qty = qty;
	this.storeId = storeId;
}
public InventorySupply() {
	super();
}


}
