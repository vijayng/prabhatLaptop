package com.vijay.handson.myecommerce.itemmanager;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

@Repository
@Transactional
public class InventoryRepository {
    @PersistenceContext
	EntityManager entityManager;
    
   /* public List<Inventory> getInventoryByItem(Item item)
    {
    	entityManager.fi
    }*/
    public void addInventory(Inventory inv)
    {
    	entityManager.persist(inv);
    }
    public Inventory GetInventory(int id)
    {
    	return entityManager.find(Inventory.class, id);
    }
    public void deleteInventory(Inventory inv) 
    {
    entityManager.remove(inv);;	
    }
    public void updateInventory(Inventory inv)
    {
    	entityManager.merge(inv);
    }
}
