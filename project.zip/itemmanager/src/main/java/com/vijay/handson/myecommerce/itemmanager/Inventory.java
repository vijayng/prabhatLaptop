package com.vijay.handson.myecommerce.itemmanager;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Inventory {
    @Id
    @GeneratedValue
    private int invKey;
	private int quantity;
	private  int store;
	@ManyToOne(fetch=FetchType.LAZY)
	@JsonIgnore
	private Item item;
	public int getInvKey() {
		return invKey;
	}
	public void setInvKey(int invKey) {
		this.invKey = invKey;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getStore() {
		return store;
	}
	public void setStore(int store) {
		this.store = store;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public Inventory() {
		super();
	}
	public Inventory(int quantity, int store, Item item) {
		super();
		this.quantity = quantity;
		this.store = store;
		this.item = item;
	}
	

}
