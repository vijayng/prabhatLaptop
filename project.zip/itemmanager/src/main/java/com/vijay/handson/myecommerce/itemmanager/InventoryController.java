package com.vijay.handson.myecommerce.itemmanager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InventoryController {

	@Autowired
	ItemRepository itemrepo;
	@Autowired
	InventoryRepository invrepo;
@GetMapping(path="/vijay/ecom/inventoryModule/item/{id}/inv")
public List<Inventory> retriveInvByItem(@PathVariable int id)
{
	return itemrepo.findbyId(id).getInvList();
}

@GetMapping(path="/vijay/ecom/inventoryModule/item/getInventory/{id}")
public Inventory adjustInventory(@PathVariable int id) {
	return invrepo.GetInventory(id);
	
}

/*@PostMapping(path="/vijay/ecom/inventoryModule/item/addInventory")
public String adjustInventory(@RequestBody Inventory inv) {
	invrepo.addInventory(inv);
	return "success";
}*/
@PutMapping(path="/vijay/ecom/inventoryModule/item/addInventory")
public void adjustInventory(@RequestBody InventorySupply invsup) {
	Item item=itemrepo.findbyId(invsup.getItemId());
	System.out.println(invsup.getQty()+" "+invsup.getStoreId()+" "+invsup.getStoreId()+" "+item);
    //check if inventory is already present against item id and WH;
	int oldinv=0;
	int newinv=invsup.getQty();
	List<Inventory> list=item.getInvList();
	for(int i=0;i<list.size();i++) 
	{
	if(list.get(i).getStore()==invsup.getStoreId())
	{
		oldinv=list.get(i).getQuantity();
	}
	}
	newinv+=oldinv;
	Inventory inv=new Inventory();
	inv.setItem(item);
	inv.setQuantity(newinv);
	inv.setStore(invsup.getStoreId());
	System.out.println("input"+invsup.getQty()+"========="+"updated"+oldinv);
	if(invsup.getQty()!=newinv)
	{
		System.out.println(" when old entry need to be update");
		
		invrepo.updateInventory(inv);
		List<Inventory> list1= inv.getItem().getInvList();
	   for(int i=0;i<list1.size();i++)
	   {
		   if(list1.get(i).getQuantity()!=newinv) {
			   invrepo.deleteInventory(list1.get(i));
		   }
	   }
	}
		else
		{
			System.out.println(" when new entry need to be made");
		invrepo.addInventory(inv);
		
		}
	
}
@GetMapping(path="/testsupply")
public InventorySupply getsamplesupplyjson() {
	System.out.println("checking sample input");
	return new InventorySupply(121212,50,105);
}

}
