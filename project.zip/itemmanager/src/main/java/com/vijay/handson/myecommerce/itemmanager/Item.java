package com.vijay.handson.myecommerce.itemmanager;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@NamedQuery(name="find_all_item", query="select i from Item i")
@Table(name="item")

public class Item {
    @Id
	int itemid;
    String description;
    String brand;
    @OneToMany(mappedBy="item")
    private List<Inventory> invList;
	public List<Inventory> getInvList() {
		return invList;
	}
	public void setInvList(List<Inventory> invList) {
		this.invList = invList;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Item(int itemid, String description, String brand) {
		super();
		this.itemid = itemid;
		this.description = description;
		this.brand = brand;
	}
	public Item() {
		
	}
    
	
}
