package com.vijay.handson.myecommerce.itemmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemmanagerApplication.class, args);
	}

}
