package com.vijay.handson.myecommerce.itemmanager;

import java.net.URI;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@Repository
@Transactional
public class ItemRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	public Item findbyId(int id)
	{
		return entityManager.find(Item.class, id);
	}
	
	public void insertItem(Item item) {
		entityManager.persist(item);
		
	}

	public void updateItem(Item item) {
		entityManager.merge(item);
		
	}

	public void deleteItem(Item item) {
		entityManager.remove(item);
		
	}
	public List<Item> getAllItem() {
		TypedQuery<Item> namedquery= entityManager.createNamedQuery("find_all_item", Item.class);
	return namedquery.getResultList();
	}
	public List<Inventory> getInventoryByItem(int id)
	{
	 return  entityManager.find(Item.class, id).getInvList();
	}
	
}
