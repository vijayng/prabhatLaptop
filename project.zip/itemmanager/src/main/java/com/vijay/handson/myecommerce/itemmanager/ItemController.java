package com.vijay.handson.myecommerce.itemmanager;

import java.net.URI;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class ItemController {

	@Autowired
	ItemRepository itemrepo;
	@GetMapping(path="/vijay/ecom/itemmodule/getitem/{id}")
	public Item retriveItem(@PathVariable int id)
	{
		return (Item)itemrepo.findbyId(id);
	}
	@PostMapping(path="/vijay/ecom/itemmodule/additem")
	public ResponseEntity<Object> addItem(@RequestBody Item item){
		
		System.out.println("i am in post method");
		itemrepo.insertItem(item);
		URI location=ServletUriComponentsBuilder.fromHttpUrl("http://localhost:8081/vijay/ecom/itemmodule/getitem/").path("{id}")
				.buildAndExpand(item.getItemid()).toUri();
		return ResponseEntity.created(location).build();
		
	}
	@PutMapping(path="/vijay/ecom/itemmodule/updateitem")
	public String updateItem(@RequestBody Item item){
		System.out.println("i am in post method");
		itemrepo.updateItem(item);
		return " update successful";
	}
	
	@DeleteMapping(path="/vijay/ecom/itemmodule/deleteitem")
	public String deleeItem(@RequestBody Item item){
		System.out.println("i am in delete method");
		itemrepo.deleteItem(item);
		return " delete successful";
	}
	@GetMapping(path="/vijay/ecom/itemmodule/getall")
	public List<Item> getAllItem()
	{
		return itemrepo.getAllItem();
	}
	@GetMapping(path="/vijay/ecom/itemmodule/getitem/{id}/Inv")
	public List<Inventory> retriveInvByItem(@PathVariable int id)
	{
		return itemrepo.findbyId(id).getInvList();
	}
}
