package com.vijay.handson.myecommerce.itemmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
