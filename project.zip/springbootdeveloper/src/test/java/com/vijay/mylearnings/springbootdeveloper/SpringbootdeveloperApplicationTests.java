package com.vijay.mylearnings.springbootdeveloper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootdeveloperApplicationTests {

	@Test
	void contextLoads() {
	}

}
