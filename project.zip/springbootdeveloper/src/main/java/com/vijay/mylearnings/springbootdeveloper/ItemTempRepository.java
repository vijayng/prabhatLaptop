package com.vijay.mylearnings.springbootdeveloper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class ItemTempRepository {

public List<Item> itemList=new ArrayList<Item>();


public List<Item> getItemList() {
	return itemList;
}

public void setItemList(List<Item> itemList) {
	this.itemList = itemList;
}

public ItemTempRepository(List<Item> itemList) {
	super();
	this.itemList = itemList;
}

public ItemTempRepository() {
	super();
}

	
	
	
}
