package com.vijay.mylearnings.springbootdeveloper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ItemSampleData {

@Autowired
ItemTempRepository itr1;

}
