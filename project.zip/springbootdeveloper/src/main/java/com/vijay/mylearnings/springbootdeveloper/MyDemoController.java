package com.vijay.mylearnings.springbootdeveloper;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyDemoController {

	@GetMapping("/target")
	public String mymethod() {
		return "vijay want to be a spring boot developer ";
	}
	@GetMapping("/sum")
	public 	int mySummethod() {
		return 8+2;
	}
}
