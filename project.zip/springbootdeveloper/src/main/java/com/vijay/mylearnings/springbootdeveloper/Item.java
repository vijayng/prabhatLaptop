package com.vijay.mylearnings.springbootdeveloper;



import com.fasterxml.jackson.annotation.JsonIgnore;


public class Item {


	private int item_id;
	private String desc;
	private Double amount;
	
	private String brand;
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Item(int item_id, String desc, double amount, String brand) {
		super();
		this.item_id = item_id;
		this.desc = desc;
		this.amount = amount;
		this.brand = brand;
	}
	public Item() {
		super();
	}
	
}
