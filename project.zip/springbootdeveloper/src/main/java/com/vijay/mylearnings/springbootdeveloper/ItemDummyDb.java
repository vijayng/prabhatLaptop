package com.vijay.mylearnings.springbootdeveloper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ItemDummyDb {

	public static List<Item> itemDB=new ArrayList();
	
	static {
		itemDB.add(new Item(1111," item1",50.0," brand a"));
		itemDB.add(new Item(2222," item2",150.0," brand b"));
		itemDB.add(new Item(3333," item3",520.0," brand c"));
		itemDB.add(new Item(4444," item4",350.0," brand d"));
		itemDB.add(new Item(5555," item5",650.0," brand e"));
	}


	
    
	
}
