package com.vijay.mylearnings.springbootdeveloper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ItemController {
    @Autowired
	ItemDummyDb a;
   
    
   
    
    @GetMapping("/getallitemlist")
    public List<Item> getAllItem()
    {
    	return ItemDummyDb.itemDB;
    }
    
    @PostMapping(path="/addItem")
    public String  newItem(@RequestBody Item item) 
    {
    	System.out.println(" i am here ");
    	System.out.println("this is executed"+ItemDummyDb.itemDB.add(item));
    	return "successful";
    }
    
   
    
    
    
    

}
