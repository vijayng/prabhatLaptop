package com.vijay.mylearnings.springbootdeveloper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MydateManipulation {

	public static void main(String args[]) throws ParseException {
		SimpleDateFormat sdf =new SimpleDateFormat("dd-MM-yy HH:mm:ss");
		Date d1=sdf.parse("05-03-2021 23:30:30");
		
		Date lastdate=new Date();
		Calendar c= Calendar.getInstance();
		c.setTime(lastdate);
		c.add(5, -29);
		c.add(10, -23);
		Date borderDate=c.getTime();
		System.out.println("test date "
				+d1);
		System.out.println("main date "
				+borderDate);
		if(borderDate.compareTo(d1)==-1)
			System.out.println("elligible");
		else
			System.out.println("date expired");
		
	}
}
