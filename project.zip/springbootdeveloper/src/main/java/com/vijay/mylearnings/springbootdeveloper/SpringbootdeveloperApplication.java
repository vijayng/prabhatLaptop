package com.vijay.mylearnings.springbootdeveloper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class SpringbootdeveloperApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootdeveloperApplication.class, args);
	}

}
